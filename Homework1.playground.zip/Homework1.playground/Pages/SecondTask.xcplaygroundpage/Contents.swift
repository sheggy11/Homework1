import UIKit

enum TypeOfReader {
  case young
  case adult
  case elderly
}


struct Reader{
    var name: String = "Ivan"
    var type: TypeOfReader = .adult
    
}

class Books {
    
    var author: String
    var theName: String
    var genre: GenreOfBook
    
    init (author: String, name: String, genre: GenreOfBook) {
        self.author = author
        self.theName = name
        self.genre = genre
    }
    
    func chooseBook(){
        print("Выберите книгу")
    }
}

class Author: Books {
    
    var country:String
    var popularity:Int
    
    init(author: String,theName:String, genre: GenreOfBook, country: String, popularity: Int) {
        self.country = country
        self.popularity = popularity
        super.init(author: author, name: theName, genre: genre)
    }

    func recalBooks() {
        if popularity > 5 {print("Автор пользуется спросом")}
    }
    
    override func chooseBook() {
        print("Книга выбрана")
    }
     
}

protocol TakeBook:Books {
    var tookBook: String {get set}
    func takeBook()
    
}

protocol CheckDebts {
    var debt:Int {get}
    func approval()
}

enum GenreOfBook {
    case scienceFiction
    case novel
    case publicism
    case detectiveNovel
}

class Debt: CheckDebts {
    var debt: Int = 10
    func approval() {
        if (debt < 10) {
            print("Выбирайте книгу")
        }
        else {
            print("Сдайте оставшуюся часть книг!")
        }
    }
}

class TakingBook: Books, TakeBook {
    var tookBook: String = "Анна Каренина"
    override func chooseBook() {
        print("Книга выбрана")
    }
    var count:Int = 0
    func takeBook() {
        count+=1
        
    }
}

